<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Tableau de bord</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Barre supérieure -->
<!--<div class="bg-white shadow p-4 flex justify-between items-center">
  <h1 class="text-lg font-semibold text-gray-700">Mon application</h1>
  <div>
    <a href="logout.php" class="text-red-600 hover:underline text-sm">🚪 Se déconnecter</a>
  </div>
</div>
-->