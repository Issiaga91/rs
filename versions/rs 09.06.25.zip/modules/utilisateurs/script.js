function ouvrirModalAjoutUtilisateur() {
  document.getElementById('modal-utilisateur-titre').innerText = "Ajouter un utilisateur";
  document.getElementById('utilisateur-id').value = "";
  document.getElementById('login').value = "";
  document.getElementById('email').value = "";
  const select = document.getElementById('dossiers');
  [...select.options].forEach(o => o.selected = false);
  document.getElementById('modal-utilisateur').classList.remove('hidden');
}

function modifierUtilisateur(id) {
  fetch('api/utilisateur.php?action=get&id=' + id)
    .then(res => res.json())
    .then(data => {
      document.getElementById('modal-utilisateur-titre').innerText = "Modifier l'utilisateur";
      document.getElementById('utilisateur-id').value = data.id;
      document.getElementById('login').value = data.login;
      document.getElementById('email').value = data.email;

      const select = document.getElementById('dossiers');
      [...select.options].forEach(o => {
        o.selected = data.dossiers.includes(parseInt(o.value));
      });

      document.getElementById('modal-utilisateur').classList.remove('hidden');
    });
}

function fermerModalUtilisateur() {
  document.getElementById('modal-utilisateur').classList.add('hidden');
}

function supprimerUtilisateur(id) {
  if (!confirm("Confirmer la suppression de cet utilisateur ?")) return;

  fetch('api/utilisateur.php?action=delete&id=' + id)
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        showToast("Utilisateur supprimé ✅");
        chargerUtilisateurs();
      } else {
        showToast(data.message || "Erreur ❌", "bg-red-500");
      }
    });
}

function initialiserFormulaireUtilisateur() {
  const form = document.getElementById('form-utilisateur');
  if (!form || form.dataset.initialised === "true") return;
  form.dataset.initialised = "true";

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(form);
    fetch('api/utilisateur.php?action=save', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          fermerModalUtilisateur();
          showToast("Utilisateur enregistré ✅");
          chargerUtilisateurs();
        } else {
          showToast(data.message || "Erreur ❌", "bg-red-500");
        }
      })
      .catch(() => showToast("Erreur réseau ❌", "bg-red-500"));
  });
}

function reinitialiserEvenementsUtilisateurs() {
  const btnAjout = document.getElementById('btn-ajouter-utilisateur');
  if (btnAjout) {
    const newBtn = btnAjout.cloneNode(true);
    btnAjout.parentNode.replaceChild(newBtn, btnAjout);
    newBtn.addEventListener('click', ouvrirModalAjoutUtilisateur);
  }
}

function chargerUtilisateurs() {
  fetch('modules/utilisateurs/tableau.php')
    .then(r => r.text())
    .then(html => {
      const container = document.getElementById('contenu-parametres');
      container.innerHTML = html;
      fetch('modules/utilisateurs/modals.php')
        .then(m => m.text())
        .then(modal => {
          container.innerHTML += modal;
          setTimeout(() => {
            initialiserFormulaireUtilisateur();
            reinitialiserEvenementsUtilisateurs();
          }, 10);
        });
    });
}
