<?php
include_once __DIR__ . '/../../db_init.php';

$sql = "SELECT u.id, u.login, u.email,
               GROUP_CONCAT(d.raison_sociale, ', ') AS dossiers
        FROM utilisateurs u
        LEFT JOIN dossier_utilisateur du ON u.id = du.id_utilisateur
        LEFT JOIN dossiers d ON du.id_dossier = d.id
        GROUP BY u.id, u.login, u.email
        ORDER BY u.login ASC";

$stmt = $pdo->query($sql);
$utilisateurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="flex justify-between items-center mb-4">
  <h2 class="text-xl font-semibold">Utilisateurs</h2>
  <button id="btn-ajouter-utilisateur" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">➕ Ajouter</button>
</div>

<div class="bg-white border rounded shadow overflow-auto">
  <table class="min-w-full text-sm text-left">
    <thead class="bg-gray-100">
      <tr>
        <th class="px-4 py-2">Nom</th>
        <th class="px-4 py-2">Email</th>
        <th class="px-4 py-2">Dossiers</th>
        <th class="px-4 py-2 text-center">Actions</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-200">
      <?php foreach ($utilisateurs as $u): ?>
        <tr>
          <td class="px-4 py-2"><?= htmlspecialchars($u['login']) ?></td>
          <td class="px-4 py-2"><?= htmlspecialchars($u['email']) ?></td>
          <td class="px-4 py-2"><?= htmlspecialchars($u['dossiers'] ?? 'Aucun') ?></td>
          <td class="px-4 py-2 text-center">
            <button onclick="modifierUtilisateur(<?= $u['id'] ?>)" class="text-orange-500 hover:text-orange-600 mr-2">✏️</button>
            <button onclick="supprimerUtilisateur(<?= $u['id'] ?>)" class="text-red-500 hover:text-red-600">🗑</button>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
