<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../db_init.php';

$action = $_GET['action'] ?? $_POST['action'] ?? null;

if (!$action) {
    echo json_encode(['success' => false, 'message' => 'Aucune action spécifiée']);
    exit;
}

switch ($action) {
    case 'save':
        $id = $_POST['id'] ?? null;
        $login = trim($_POST['login'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $dossiers = $_POST['dossiers'] ?? [];

        if (!$login || !$email) {
            echo json_encode(['success' => false, 'message' => 'Login et email requis']);
            exit;
        }

        try {
            if ($id) {
                $stmt = $pdo->prepare("UPDATE utilisateurs SET login = ?, email = ? WHERE id = ?");
                $stmt->execute([$login, $email, $id]);

                $pdo->prepare("DELETE FROM dossier_utilisateur WHERE id_utilisateur = ?")->execute([$id]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO utilisateurs (login, email, mot_de_passe) VALUES (?, ?, NULL)");
                $stmt->execute([$login, $email]);
                $id = $pdo->lastInsertId();
            }

            $stmt = $pdo->prepare("INSERT INTO dossier_utilisateur (id_utilisateur, id_dossier) VALUES (?, ?)");
            foreach ($dossiers as $d) {
                if (is_numeric($d)) $stmt->execute([$id, $d]);
            }

            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Erreur : ' . $e->getMessage()]);
        }
        break;

    case 'get':
        $id = $_GET['id'] ?? null;
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'ID manquant']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("SELECT id_dossier FROM dossier_utilisateur WHERE id_utilisateur = ?");
        $stmt->execute([$id]);
        $user['dossiers'] = $stmt->fetchAll(PDO::FETCH_COLUMN);

        echo json_encode($user);
        break;

    case 'delete':
        $id = $_GET['id'] ?? null;
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'ID manquant']);
            exit;
        }

        $stmt = $pdo->prepare("DELETE FROM utilisateurs WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(['success' => true]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Action invalide']);
}
